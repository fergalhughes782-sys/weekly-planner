MY WEEKLY PLANNER — INSTALLABLE APP BUNDLE

Files:
- index.html: the planner app
- manifest.webmanifest: app name, icon and home-screen settings
- sw.js: offline caching
- icons/: app icons

PROGRESS
Checklist progress is saved in localStorage on the device/browser where you use the app. It is not synced between devices and can be removed if browser/site data is cleared.

HOW TO USE
1. Unzip this folder.
2. Open index.html to use the planner in a browser. Basic planner features work locally.
3. To install it as a proper home-screen app with an icon and offline app shell, publish the contents of this folder to an HTTPS static host (for example GitHub Pages or Netlify).
4. Visit the hosted HTTPS URL on your phone. On iPhone, open it in Safari, tap Share, then Add to Home Screen. On supported browsers, an Install app button may appear.
5. Open the home-screen icon. Once the app has loaded online once, its core files are cached for offline use.

NOTE
Service workers and installable PWA features do not run from a file:// URL. They require HTTPS (or localhost). The included bundle is ready for static HTTPS hosting.
